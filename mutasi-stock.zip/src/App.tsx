import React, { useState, useMemo, useEffect } from 'react';
import { Download, TrendingUp, AlertTriangle, CheckCircle2, Filter, AlertOctagon, Search, ChevronLeft, ChevronRight, Database, RefreshCw, UploadCloud, LogOut, Settings, Building2 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import * as XLSX from 'xlsx';
import { mockDatabase, PartData } from './data/mockData';
import { calculateAvgDemand, calculateMOS, TimeFilter } from './utils/calculations';
import { SettingsModal } from './components/SettingsModal';
import { UploadModal } from './components/UploadModal';
import { Login } from './components/Login';
import { AdminSettings } from './components/AdminSettings';
import { User, Branch, CurrentUser } from './types';

type TabType = 'POB' | 'YGP' | 'OOB';
type ABCCategoryFilter = 'ALL' | 'A' | 'B' | 'C';
type StatusFilter = 'ALL' | 'AMAN' | 'RESTOCK' | 'OVERSTOCK' | 'DEAD_STOCK';

// Thresholds based on Yamaha Distributor Standards
const THRESHOLD_RESTOCK = 1.5; // MOS < 1.5 months means restock
const THRESHOLD_OVERSTOCK = 4.0; // MOS > 4.0 months means overstock

// Komponen Mini Chart (Sparkline) untuk setiap baris
const Sparkline = ({ data }: { data: number[] }) => {
  const chartData = data.map((val, i) => ({ index: i, value: val }));
  
  // Tentukan warna berdasarkan tren (naik/turun/datar)
  const firstHalf = data.slice(0, Math.floor(data.length / 2)).reduce((a, b) => a + b, 0);
  const secondHalf = data.slice(Math.floor(data.length / 2)).reduce((a, b) => a + b, 0);
  const color = secondHalf > firstHalf ? '#10b981' : secondHalf < firstHalf ? '#ef4444' : '#6366f1';

  return (
    <div className="h-6 w-20">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <Line 
            type="monotone" 
            dataKey="value" 
            stroke={color} 
            strokeWidth={2} 
            dot={false} 
            isAnimationActive={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default function App() {
  const [inventoryData, setInventoryData] = useState<PartData[]>(mockDatabase);
  const [masterData, setMasterData] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('POB');
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('J1');
  const [abcFilter, setAbcFilter] = useState<ABCCategoryFilter>('ALL');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(50);

  // Auth & Multi-Branch State
  const [users, setUsers] = useState<User[]>(() => {
    const defaultAdmin: User = { id: '1', username: 'admin', password: 'password', role: 'admin', branchIds: [] };
    const saved = localStorage.getItem('users');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Ensure default admin exists and has correct credentials
          const adminIndex = parsed.findIndex(u => u.id === '1');
          if (adminIndex >= 0) {
            parsed[adminIndex] = { ...parsed[adminIndex], username: 'admin', password: 'password', role: 'admin' };
          } else {
            parsed.unshift(defaultAdmin);
          }
          return parsed;
        }
      } catch (e) {
        console.error("Error parsing users from localStorage", e);
      }
    }
    return [defaultAdmin];
  });
  const [branches, setBranches] = useState<Branch[]>(() => {
    const saved = localStorage.getItem('branches');
    if (saved) return JSON.parse(saved);
    return [];
  });
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(() => {
    const saved = localStorage.getItem('currentUser');
    if (saved) return JSON.parse(saved);
    return null;
  });
  const [currentBranchId, setCurrentBranchId] = useState<string>(() => {
    return localStorage.getItem('currentBranchId') || '';
  });
  const [isAdminSettingsOpen, setIsAdminSettingsOpen] = useState(false);

  // Settings Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [masterGasUrl, setMasterGasUrl] = useState(() => localStorage.getItem('masterGasUrl') || '');
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSavingToDB, setIsSavingToDB] = useState(false);
  const [syncError, setSyncError] = useState('');

  // Persist state
  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('branches', JSON.stringify(branches));
  }, [branches]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('currentUser');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('currentBranchId', currentBranchId);
    // When branch changes, fetch data if masterGasUrl is set
    const branch = branches.find(b => b.id === currentBranchId);
    if (branch && branch.spreadsheetId && masterGasUrl) {
      fetchInventoryData(masterGasUrl, branch.spreadsheetId);
    } else {
      setInventoryData([]);
      setMasterData([]);
    }
  }, [currentBranchId, branches, masterGasUrl]);

  // Auto-select first branch if none selected
  useEffect(() => {
    if (!currentBranchId && currentUser && branches.length > 0) {
      const availableBranches = currentUser.role === 'admin' 
        ? branches 
        : branches.filter(b => currentUser.branchIds.includes(b.id));
      
      if (availableBranches.length > 0) {
        setCurrentBranchId(availableBranches[0].id);
      }
    }
  }, [branches, currentUser, currentBranchId]);

  const handleLogin = (user: User) => {
    const { password, ...userWithoutPassword } = user;
    setCurrentUser(userWithoutPassword);
    
    // Auto-select first branch if available
    let availableBranches = branches;
    if (user.role !== 'admin') {
      availableBranches = branches.filter(b => user.branchIds.includes(b.id));
    }
    
    if (availableBranches.length > 0 && !currentBranchId) {
      setCurrentBranchId(availableBranches[0].id);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentBranchId('');
    setInventoryData([]);
    setMasterData([]);
  };

  const handleSaveMasterUrl = async (url: string) => {
    setMasterGasUrl(url);
    localStorage.setItem('masterGasUrl', url);
    setIsSettingsOpen(false);
    
    // Fetch data if a branch is selected and has a spreadsheetId
    const branch = branches.find(b => b.id === currentBranchId);
    if (branch && branch.spreadsheetId) {
      await fetchInventoryData(url, branch.spreadsheetId);
    }
  };

  // Fetch data from GAS
  const fetchInventoryData = async (url: string, spreadsheetId?: string) => {
    setIsSyncing(true);
    setSyncError('');
    try {
      const branch = branches.find(b => b.id === currentBranchId);
      const targetSpreadsheetId = spreadsheetId || (branch ? branch.spreadsheetId : null);
      
      if (!targetSpreadsheetId) {
        throw new Error('Spreadsheet ID tidak ditemukan untuk cabang ini');
      }

      // 1. Fetch Master Data
      let currentMasterData = [];
      try {
        const masterRes = await fetch(`${url}?sheet=MasterData&spreadsheetId=${targetSpreadsheetId}`);
        if (masterRes.ok) {
          const mData = await masterRes.json();
          if (Array.isArray(mData)) {
            currentMasterData = mData;
            setMasterData(mData);
          }
        }
      } catch (e) {
        console.warn("Could not fetch MasterData", e);
      }

      // 2. Fetch Inventory Data
      const response = await fetch(`${url}?sheet=Inventory&spreadsheetId=${targetSpreadsheetId}`);
      if (!response.ok) throw new Error('Gagal mengambil data dari server');
      const data = await response.json();
      if (data.error) throw new Error(data.error);

      // Pastikan data yang diterima valid
      if (Array.isArray(data)) {
        // Map data from GAS to match PartData structure, merging with MasterData
        const mappedData: PartData[] = data.map((item: any) => {
          const partNo = item.partNo || item.partNumber;
          const mItem = currentMasterData.find((m: any) => (m.partNo || m.partNumber) === partNo);
          return {
            partNo: partNo,
            partName: item.name,
            category: mItem ? mItem.category : (item.category || 'OOB'),
            abcCategory: mItem ? mItem.abcCategory : (item.abcCategory || 'C'),
            stockQty: item.stock,
            j1Total: item.j1Total || 0,
            j2Total: item.j2Total || 0,
            monthlyDemand: (item.history && item.history.length > 0) ? item.history : Array(12).fill(0),
          };
        });
        setInventoryData(mappedData);
      } else {
        throw new Error('Format data tidak sesuai');
      }
    } catch (err: any) {
      setSyncError(err.message || 'Terjadi kesalahan saat sinkronisasi');
    } finally {
      setIsSyncing(false);
    }
  };

  // Auto-fetch on load if URL exists
  useEffect(() => {
    if (masterGasUrl && currentBranchId) {
      const branch = branches.find(b => b.id === currentBranchId);
      if (branch && branch.spreadsheetId) {
        fetchInventoryData(masterGasUrl, branch.spreadsheetId);
      }
    }
  }, []);

  // Handle Upload Success (DB1)
  const handleUploadSuccess = async (data: PartData[], onProgress?: (progress: number) => void) => {
    // Merge with existing masterData
    const mergedData = data.map(item => {
      const mItem = masterData.find(m => m.partNo === item.partNo);
      return {
        ...item,
        category: mItem ? mItem.category : item.category,
        abcCategory: mItem ? mItem.abcCategory : item.abcCategory,
      };
    });

    setInventoryData(mergedData);
    
    // Jika ada URL GAS, otomatis simpan ke database
    if (masterGasUrl) {
      setIsSavingToDB(true);
      try {
        const branch = branches.find(b => b.id === currentBranchId);
        if (!branch || !branch.spreadsheetId) throw new Error('Spreadsheet ID tidak ditemukan');

        const chunkSize = 500;
        const totalChunks = Math.ceil(mergedData.length / chunkSize);
        
        for (let i = 0; i < totalChunks; i++) {
          const chunk = mergedData.slice(i * chunkSize, (i + 1) * chunkSize);
          const action = i === 0 ? 'overwrite' : 'append';
          
          const response = await fetch(masterGasUrl, {
            method: 'POST',
            body: JSON.stringify({ 
              sheet: 'Inventory', 
              spreadsheetId: branch.spreadsheetId, 
              data: chunk,
              action: action
            }),
            headers: {
              'Content-Type': 'text/plain;charset=utf-8',
            }
          });
          
          const result = await response.json();
          if (result.error) throw new Error(result.error);
          
          if (onProgress) {
            onProgress(Math.round(((i + 1) / totalChunks) * 100));
          }
        }
        
        alert('Data Stok berhasil di-upload dan disimpan ke Database!');
      } catch (err: any) {
        alert('Data Stok berhasil di-upload ke aplikasi, tapi gagal disimpan ke Database: ' + err.message);
      } finally {
        setIsSavingToDB(false);
      }
    } else {
      if (onProgress) onProgress(100);
      alert('Data Stok berhasil di-upload! (Hanya tersimpan sementara karena Database belum di-setup)');
    }
  };

  // Handle Upload Master Success (DB2)
  const handleUploadMasterSuccess = async (data: any[], onProgress?: (progress: number) => void) => {
    setMasterData(data);

    // Update existing inventory data with new master data
    const updatedInventory = inventoryData.map(item => {
      const mItem = data.find(m => m.partNo === item.partNo);
      if (mItem) {
        return { ...item, category: mItem.category, abcCategory: mItem.abcCategory };
      }
      return item;
    });
    setInventoryData(updatedInventory);

    if (masterGasUrl) {
      setIsSavingToDB(true);
      try {
        const branch = branches.find(b => b.id === currentBranchId);
        if (!branch || !branch.spreadsheetId) throw new Error('Spreadsheet ID tidak ditemukan');

        const chunkSize = 500;
        const totalChunks = Math.ceil(data.length / chunkSize);
        
        for (let i = 0; i < totalChunks; i++) {
          const chunk = data.slice(i * chunkSize, (i + 1) * chunkSize);
          const action = i === 0 ? 'overwrite' : 'append';
          
          const response = await fetch(masterGasUrl, {
            method: 'POST',
            body: JSON.stringify({ 
              sheet: 'MasterData', 
              spreadsheetId: branch.spreadsheetId, 
              data: chunk,
              action: action
            }),
            headers: {
              'Content-Type': 'text/plain;charset=utf-8',
            }
          });
          
          const result = await response.json();
          if (result.error) throw new Error(result.error);
          
          if (onProgress) {
            onProgress(Math.round(((i + 1) / totalChunks) * 100));
          }
        }
        
        alert('Master Data berhasil di-upload dan disimpan ke Database!');
      } catch (err: any) {
        alert('Master Data berhasil di-upload ke aplikasi, tapi gagal disimpan ke Database: ' + err.message);
      } finally {
        setIsSavingToDB(false);
      }
    } else {
      if (onProgress) onProgress(100);
      alert('Master Data berhasil di-upload! (Hanya tersimpan sementara karena Database belum di-setup)');
    }
  };

  // 1. Kalkulasi Data Dasar (Avg Demand & MOS) untuk semua item
  const baseData = useMemo(() => {
    return inventoryData.map((part) => {
      const avgDemand = calculateAvgDemand(part, timeFilter);
      const mos = calculateMOS(part.stockQty, avgDemand);
      const isDeadStock = part.stockQty > 0 && part.j1Total === 0;
      
      let status: StatusFilter = 'AMAN';
      if (isDeadStock || mos === 999) status = 'DEAD_STOCK';
      else if (mos > THRESHOLD_OVERSTOCK) status = 'OVERSTOCK';
      else if (mos < THRESHOLD_RESTOCK) status = 'RESTOCK';

      return { ...part, avgDemand, mos, isDeadStock, status };
    });
  }, [timeFilter]);

  // 2. Filter Data berdasarkan Tab, ABC, Status, dan Pencarian
  const filteredData = useMemo(() => {
    return baseData.filter((part) => {
      // Filter Tab
      let tabMatch = false;
      if (activeTab === 'POB') tabMatch = part.category === 'POB';
      else if (activeTab === 'YGP') tabMatch = part.category === 'YGP';
      else if (activeTab === 'OOB') tabMatch = part.category === 'OOB' || part.category === 'OIL';
      
      // Filter ABC
      const abcMatch = abcFilter === 'ALL' || part.abcCategory === abcFilter;

      // Filter Status
      const statusMatch = statusFilter === 'ALL' || part.status === statusFilter;

      // Filter Pencarian (Part No atau Part Name)
      const searchMatch = searchQuery === '' || 
        part.partNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
        part.partName.toLowerCase().includes(searchQuery.toLowerCase());

      return tabMatch && abcMatch && statusMatch && searchMatch;
    });
  }, [baseData, activeTab, abcFilter, statusFilter, searchQuery]);

  // Reset pagination when filters change
  useMemo(() => {
    setCurrentPage(1);
  }, [activeTab, abcFilter, statusFilter, searchQuery, timeFilter]);

  // 3. Pagination Logic
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredData, currentPage, itemsPerPage]);

  // Data untuk grafik tren (menggunakan item pertama dari data yang difilter sebagai contoh)
  const trendData = useMemo(() => {
    if (filteredData.length === 0) return [];
    // Cari item dengan demand tertinggi untuk ditampilkan di grafik utama
    const topItem = [...filteredData].sort((a, b) => b.j1Total - a.j1Total)[0];
    return topItem.monthlyDemand.map((demand, index) => ({
      month: `N${(index + 1).toString().padStart(2, '0')}`,
      demand: demand,
    }));
  }, [filteredData]);

  // Hitung statistik untuk Smart Analysis (Berdasarkan Tab Aktif saja, abaikan filter lain agar stat tetap utuh)
  const stats = useMemo(() => {
    const tabData = baseData.filter(part => {
      if (activeTab === 'POB') return part.category === 'POB';
      if (activeTab === 'YGP') return part.category === 'YGP';
      if (activeTab === 'OOB') return part.category === 'OOB' || part.category === 'OIL';
      return false;
    });

    const totalItems = tabData.length;
    const overstockCount = tabData.filter(item => item.status === 'OVERSTOCK').length;
    const deadstockCount = tabData.filter(item => item.status === 'DEAD_STOCK').length;
    const restockCount = tabData.filter(item => item.status === 'RESTOCK').length;
    return { totalItems, overstockCount, deadstockCount, restockCount };
  }, [baseData, activeTab]);

  // Fungsi Export ke Excel
  const handleExportExcel = () => {
    const exportData = filteredData.map((item) => ({
      'Part No.': item.partNo,
      'Parts Name': item.partName,
      'Category': item.category,
      'ABC Category': item.abcCategory,
      'Avg Demand': item.avgDemand,
      'Stock Qty': item.stockQty,
      'MOS': item.mos,
      'Status': item.status
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, `${activeTab}_Report`);
    XLSX.writeFile(workbook, `Laporan_Distributor_${activeTab}_${timeFilter}.xlsx`);
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} users={users} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-4">
        
        {/* Header & Controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-5 rounded-xl shadow-sm border border-slate-200">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Dashboard Inventori Distributor</h1>
            <p className="text-xs text-slate-500 mt-1">Pantau pergerakan stok, tren demand, dan cegah dead stock.</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            {/* Branch Selector */}
            {branches.length > 0 && (
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5">
                <Building2 className="w-4 h-4 text-slate-500" />
                <select
                  value={currentBranchId}
                  onChange={(e) => setCurrentBranchId(e.target.value)}
                  className="bg-transparent border-none text-sm font-medium text-slate-700 focus:ring-0 cursor-pointer outline-none"
                >
                  <option value="" disabled>Pilih Cabang</option>
                  {branches
                    .filter(b => currentUser.role === 'admin' || currentUser.branchIds.includes(b.id))
                    .map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            )}

            {/* User Menu */}
            <div className="flex items-center gap-3 pl-3 border-l border-slate-200">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-slate-800">{currentUser.username}</p>
                <p className="text-xs text-slate-500 capitalize">{currentUser.role}</p>
              </div>
              
              {currentUser.role === 'admin' && (
                <button 
                  onClick={() => setIsAdminSettingsOpen(true)}
                  className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors"
                  title="Pengaturan Admin"
                >
                  <Settings className="w-5 h-5" />
                </button>
              )}
              
              <button 
                onClick={handleLogout}
                className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                title="Keluar"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => {
                if (!currentBranchId) {
                  alert('Silakan tambah dan pilih cabang terlebih dahulu di Pengaturan Admin.');
                  return;
                }
                setIsUploadOpen(true);
              }}
              disabled={isSavingToDB}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all shadow-sm text-xs font-medium ${
                !currentBranchId 
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'
              }`}
              title={!currentBranchId ? "Pilih cabang terlebih dahulu" : "Upload Data"}
            >
              {isSavingToDB ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
              <span>{isSavingToDB ? 'Menyimpan...' : (!currentBranchId ? 'Pilih Cabang Dulu' : 'Upload Data')}</span>
            </button>
            
            {currentUser.role === 'admin' && (
              <button 
                onClick={() => setIsSettingsOpen(true)}
                className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm text-xs font-medium"
              >
                <Database className="w-4 h-4 text-indigo-500" />
                <span>Script Setup</span>
              </button>
            )}
            
            {masterGasUrl && currentBranchId && (
              <button 
                onClick={() => fetchInventoryData(masterGasUrl)}
                disabled={isSyncing}
                className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-lg hover:bg-indigo-100 transition-all shadow-sm text-xs font-medium disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>Sync</span>
              </button>
            )}
          </div>
          
          <div className="flex items-center gap-3">
            {/* Filter Waktu */}
            <div className="flex items-center bg-slate-100 rounded-lg p-1">
              {(['J1', 'J2', 'ALL'] as TimeFilter[]).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setTimeFilter(filter)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    timeFilter === filter 
                      ? 'bg-white text-indigo-600 shadow-sm' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {filter === 'ALL' ? 'Semua (J1+J2)' : filter}
                </button>
              ))}
            </div>
            
            <button 
              onClick={handleExportExcel}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-xs font-medium transition-colors"
            >
              <Download className="w-4 h-4" />
              Export Excel
            </button>
          </div>
        </div>

        {/* Smart Analysis Section */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-semibold text-slate-800">Ringkasan Gudang ({activeTab})</h2>
            </div>
            <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2 py-1 rounded-md">
              Total: {stats.totalItems.toLocaleString()} Item
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {/* Stat: Restock */}
            <div 
              onClick={() => setStatusFilter(statusFilter === 'RESTOCK' ? 'ALL' : 'RESTOCK')}
              className={`p-3 rounded-lg border flex flex-col justify-between cursor-pointer transition-all ${statusFilter === 'RESTOCK' ? 'bg-amber-50 border-amber-300 ring-1 ring-amber-200' : 'bg-slate-50 border-slate-100 hover:border-amber-200'}`}
            >
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-medium text-slate-700">Butuh Restock</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">MOS &lt; {THRESHOLD_RESTOCK} bulan</p>
                </div>
              </div>
              <p className="text-xl font-bold text-amber-600 mt-2">{stats.restockCount.toLocaleString()}</p>
            </div>

            {/* Stat: Overstock */}
            <div 
              onClick={() => setStatusFilter(statusFilter === 'OVERSTOCK' ? 'ALL' : 'OVERSTOCK')}
              className={`p-3 rounded-lg border flex flex-col justify-between cursor-pointer transition-all ${statusFilter === 'OVERSTOCK' ? 'bg-indigo-50 border-indigo-300 ring-1 ring-indigo-200' : 'bg-slate-50 border-slate-100 hover:border-indigo-200'}`}
            >
              <div className="flex items-start gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5 transform rotate-180" />
                <div>
                  <p className="text-xs font-medium text-slate-700">Overstock</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">MOS &gt; {THRESHOLD_OVERSTOCK} bulan</p>
                </div>
              </div>
              <p className="text-xl font-bold text-indigo-600 mt-2">{stats.overstockCount.toLocaleString()}</p>
            </div>

            {/* Stat: Dead Stock */}
            <div 
              onClick={() => setStatusFilter(statusFilter === 'DEAD_STOCK' ? 'ALL' : 'DEAD_STOCK')}
              className={`p-3 rounded-lg border flex flex-col justify-between cursor-pointer transition-all ${statusFilter === 'DEAD_STOCK' ? 'bg-red-50 border-red-300 ring-1 ring-red-200' : 'bg-slate-50 border-slate-100 hover:border-red-200'}`}
            >
              <div className="flex items-start gap-2">
                <AlertOctagon className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-medium text-slate-700">Dead Stock</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Demand 0 (J1)</p>
                </div>
              </div>
              <p className="text-xl font-bold text-red-600 mt-2">{stats.deadstockCount.toLocaleString()}</p>
            </div>

            {/* Trend Chart */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
              <p className="text-[10px] font-mono text-slate-500 mb-1">TREN ITEM TERLARIS</p>
              <div className="h-10 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData}>
                    <Line type="monotone" dataKey="demand" stroke="#4f46e5" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs & Advanced Filters */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-3 border-b border-slate-200 pb-2">
          <div className="flex space-x-1">
            {(['POB', 'YGP', 'OOB'] as TabType[]).map((tab) => (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setStatusFilter('ALL'); // Reset status filter when changing tabs
                }}
                className={`px-5 py-2.5 text-xs font-medium border-b-2 transition-colors ${
                  activeTab === tab
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                {tab === 'YGP' ? 'YGP + AKSESORIS' : tab === 'OOB' ? 'OOB + OIL' : tab}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2 pb-1">
            {/* Search Bar */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none">
                <Search className="h-3.5 w-3.5 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Cari Part No / Nama..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 w-full md:w-56"
              />
            </div>

            {/* Filter Status Dropdown */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-md px-2 py-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
                className="bg-transparent text-xs font-medium text-slate-700 outline-none cursor-pointer"
              >
                <option value="ALL">Semua Status</option>
                <option value="RESTOCK">Butuh Restock</option>
                <option value="OVERSTOCK">Overstock</option>
                <option value="DEAD_STOCK">Dead Stock</option>
                <option value="AMAN">Stok Aman</option>
              </select>
            </div>

            {/* Filter ABC Category */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-md px-2 py-1.5">
              <select 
                value={abcFilter}
                onChange={(e) => setAbcFilter(e.target.value as ABCCategoryFilter)}
                className="bg-transparent text-xs font-medium text-slate-700 outline-none cursor-pointer"
              >
                <option value="ALL">Semua Kelas</option>
                <option value="A">Kelas A (Fast)</option>
                <option value="B">Kelas B (Med)</option>
                <option value="C">Kelas C (Slow)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Data Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200 sticky top-0 z-10">
                <tr>
                  <th className="px-4 py-3">
                    {activeTab === 'POB' && 'PART (Part No)'}
                    {activeTab === 'YGP' && 'CAT (ABC Category)'}
                    {activeTab === 'OOB' && 'NAMA (Part Name)'}
                  </th>
                  {activeTab === 'YGP' && <th className="px-4 py-3">PART NO</th>}
                  <th className="px-4 py-3 text-center">TREN (12 BLN)</th>
                  <th className="px-4 py-3 text-right">AVG DEMAND</th>
                  <th className="px-4 py-3 text-right">STOCK</th>
                  <th className="px-4 py-3 text-right">MOS</th>
                  <th className="px-4 py-3 text-center">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedData.map((row, idx) => (
                  <tr key={idx} className={`transition-colors ${row.status === 'DEAD_STOCK' ? 'bg-red-50/30 hover:bg-red-50/50' : 'hover:bg-slate-50/80'}`}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">
                      <div className="flex flex-col">
                        {activeTab === 'POB' && <span>{row.partNo}</span>}
                        {activeTab === 'YGP' && (
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold w-fit ${
                            row.abcCategory === 'A' ? 'bg-emerald-100 text-emerald-800' :
                            row.abcCategory === 'B' ? 'bg-blue-100 text-blue-800' :
                            'bg-slate-100 text-slate-800'
                          }`}>
                            Kelas {row.abcCategory}
                          </span>
                        )}
                        {activeTab === 'OOB' && <span className="truncate max-w-[200px]">{row.partName}</span>}
                        
                        {activeTab !== 'OOB' && (
                          <span className="text-[10px] text-slate-500 mt-0.5 font-normal truncate max-w-[200px]">
                            {row.partName}
                          </span>
                        )}
                      </div>
                    </td>
                    {activeTab === 'YGP' && (
                      <td className="px-4 py-2.5 text-slate-600 font-mono text-[11px]">{row.partNo}</td>
                    )}
                    <td className="px-4 py-2.5">
                      <div className="flex justify-center">
                        <Sparkline data={row.monthlyDemand} />
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-600">{row.avgDemand}</td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-900 font-semibold">{row.stockQty}</td>
                    <td className="px-4 py-2.5 text-right font-mono">
                      <span className={
                        row.status === 'DEAD_STOCK' ? 'text-red-600 font-bold' :
                        row.status === 'OVERSTOCK' ? 'text-indigo-600 font-semibold' : 
                        row.status === 'RESTOCK' ? 'text-amber-600 font-semibold' : 
                        'text-emerald-600 font-semibold'
                      }>
                        {row.status === 'DEAD_STOCK' ? '∞' : row.mos}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      {row.status === 'DEAD_STOCK' ? (
                        <span className="text-[10px] font-bold text-red-700 bg-red-100 px-1.5 py-0.5 rounded border border-red-200">DEAD STOCK</span>
                      ) : row.status === 'OVERSTOCK' ? (
                        <span className="text-[10px] font-medium text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-100">Overstock</span>
                      ) : row.status === 'RESTOCK' ? (
                        <span className="text-[10px] font-medium text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">Restock</span>
                      ) : (
                        <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">Aman</span>
                      )}
                    </td>
                  </tr>
                ))}
                {paginatedData.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                      <div className="flex flex-col items-center justify-center">
                        <Search className="w-6 h-6 text-slate-300 mb-2" />
                        <p>Tidak ada data yang cocok dengan filter atau pencarian Anda.</p>
                        <button 
                          onClick={() => {
                            setSearchQuery('');
                            setStatusFilter('ALL');
                            setAbcFilter('ALL');
                          }}
                          className="mt-2 text-indigo-600 hover:text-indigo-700 text-xs font-medium"
                        >
                          Reset Filter
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination Controls */}
          {filteredData.length > 0 && (
            <div className="bg-slate-50 border-t border-slate-200 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Tampilkan</span>
                <select 
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="bg-white border border-slate-200 rounded text-xs py-1 px-2 outline-none"
                >
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                  <option value={500}>500</option>
                </select>
                <span className="text-xs text-slate-500">baris per halaman</span>
              </div>
              
              <div className="flex items-center gap-4">
                <span className="text-xs text-slate-600">
                  Menampilkan <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span> - <span className="font-medium">{Math.min(currentPage * itemsPerPage, filteredData.length)}</span> dari <span className="font-medium">{filteredData.length}</span> data
                </span>
                
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="p-1 rounded hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4 text-slate-600" />
                  </button>
                  <span className="text-xs font-medium text-slate-700 px-2">
                    {currentPage} / {totalPages}
                  </span>
                  <button 
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="p-1 rounded hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <ChevronRight className="w-4 h-4 text-slate-600" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
      
      {/* Settings Modal */}
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onSync={handleSaveMasterUrl}
        initialUrl={masterGasUrl}
        isSyncing={isSyncing}
        syncError={syncError}
      />

      {/* Upload Modal */}
      <UploadModal 
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={handleUploadSuccess}
        onUploadMasterSuccess={handleUploadMasterSuccess}
      />

      {/* Admin Settings Modal */}
      <AdminSettings
        isOpen={isAdminSettingsOpen}
        onClose={() => setIsAdminSettingsOpen(false)}
        users={users}
        branches={branches}
        onSaveUsers={setUsers}
        onSaveBranches={setBranches}
      />
    </div>
  );
}
