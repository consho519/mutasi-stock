import React, { useState, useRef } from 'react';
import { X, UploadCloud, FileSpreadsheet, AlertCircle, CheckCircle2, Loader2, Database, Layers } from 'lucide-react';
import * as XLSX from 'xlsx';
import { PartData } from '../data/mockData';

export interface MasterData {
  partNo: string;
  category: string;
  abcCategory: string;
}

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (data: PartData[], onProgress?: (progress: number) => void) => Promise<void>;
  onUploadMasterSuccess: (data: MasterData[], onProgress?: (progress: number) => void) => Promise<void>;
}

type UploadType = 'inventory' | 'master';

export function UploadModal({ isOpen, onClose, onUploadSuccess, onUploadMasterSuccess }: UploadModalProps) {
  const [activeTab, setActiveTab] = useState<UploadType>('inventory');
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const processExcel = (file: File) => {
    setIsLoading(true);
    setError('');
    setProgress(0);
    
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const ab = evt.target?.result;
        const wb = XLSX.read(ab, { type: 'array' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        if (activeTab === 'inventory') {
          const data = XLSX.utils.sheet_to_json(ws);
          if (data.length === 0) {
            throw new Error('File Excel kosong atau format tidak sesuai.');
          }

          // Smart Mapping untuk DB1 (Stok & Demand)
          const mappedData: PartData[] = data.map((row: any) => {
            const keys = Object.keys(row);
            const getVal = (possibleKeys: string[]) => {
              const key = keys.find(k => possibleKeys.some(pk => k.toLowerCase().includes(pk)));
              return key ? row[key] : undefined;
            };

            const partNo = getVal(['parts no.(-)', 'parts no.', 'part_n', 'printed', 'part no', 'part number', 'kode', 'item']) || 'UNKNOWN';
            const partName = getVal(['parts name', 'part_name', 'part name', 'nama', 'description', 'desc']) || 'Unknown Part';
            const stockQty = parseInt(getVal(['stock q', 'stock', 'stok', 'qty', 'sisa'])) || 0;
            const category = getVal(['large_g', 'categor', 'kategori', 'category', 'group', 'jenis']) || 'OOB';
            const abcCategory = getVal(['abc catego', 'abc category', 'abc', 'kelas', 'class', 'rank']) || 'C';
            
            // Mencari kolom demand/history (N11 sampai N00)
            let monthlyDemand: number[] = [];
            const nCols = ['n11', 'n10', 'n09', 'n08', 'n07', 'n06', 'n05', 'n04', 'n03', 'n02', 'n01', 'n00'];
            const hasNCols = nCols.every(ncol => keys.some(k => k.toLowerCase() === ncol));
            
            if (hasNCols) {
              monthlyDemand = nCols.map(ncol => {
                const key = keys.find(k => k.toLowerCase() === ncol);
                return key ? (parseInt(row[key]) || 0) : 0;
              });
            } else {
              const demandKeys = keys.filter(k => 
                k.toLowerCase().includes('demand') || 
                k.toLowerCase().includes('bulan') || 
                ['jan', 'feb', 'mar', 'apr', 'mei', 'jun', 'jul', 'agu', 'sep', 'okt', 'nov', 'des'].some(m => k.toLowerCase().includes(m))
              );
              monthlyDemand = demandKeys.map(k => parseInt(row[k]) || 0);
            }
            
            if (monthlyDemand.length === 0) {
              monthlyDemand = Array(12).fill(0);
            }

            const j1Total = parseInt(getVal(['j1 tot', 'j1 total', 'j1'])) || monthlyDemand.reduce((a, b) => a + b, 0);
            const j2Total = parseInt(getVal(['j2 tot', 'j2 total', 'j2'])) || 0;

            return {
              partNo: String(partNo),
              partName: String(partName),
              category: String(category),
              abcCategory: String(abcCategory),
              stockQty,
              j1Total,
              j2Total,
              monthlyDemand
            };
          });
          await onUploadSuccess(mappedData, setProgress);
        } else {
          // DB2 (Master Data) - VLOOKUP style
          // Menggunakan header: 1 untuk mendapatkan array of arrays (baris x kolom)
          const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
          if (data.length <= 1) {
            throw new Error('File Excel kosong atau format tidak sesuai.');
          }

          // Lewati baris pertama (header)
          const rows = data.slice(1);
          
          const mappedMaster: MasterData[] = rows.map((row: any[]) => {
            // Asumsi: 
            // Kolom A (index 0) atau B (index 1) adalah Part Number
            // Kolom F (index 5) adalah Category
            // Kolom G (index 6) adalah ABC Category
            
            // Coba ambil Part Number dari kolom A atau B
            const partNo = row[0] || row[1] || 'UNKNOWN';
            
            // Ambil Category dari kolom F (index 5)
            const category = row[5] || 'OOB';
            
            // Ambil ABC Category dari kolom G (index 6)
            const abcCategory = row[6] || 'C';

            return {
              partNo: String(partNo),
              category: String(category),
              abcCategory: String(abcCategory)
            };
          }).filter(item => item.partNo !== 'UNKNOWN');
          
          await onUploadMasterSuccess(mappedMaster, setProgress);
        }
        
        onClose();
      } catch (err: any) {
        setError(err.message || 'Gagal memproses file Excel. Pastikan formatnya benar.');
      } finally {
        setIsLoading(false);
        setProgress(0);
      }
    };
    reader.onerror = () => {
      setError('Gagal membaca file.');
      setIsLoading(false);
      setProgress(0);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv')) {
        processExcel(file);
      } else {
        setError('Mohon upload file Excel (.xlsx, .xls) atau CSV.');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processExcel(e.target.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Upload Data</h2>
              <p className="text-xs text-slate-500">Upload file Excel/CSV dari sistem internal Anda</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:bg-slate-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-100">
          <button
            onClick={() => { setActiveTab('inventory'); setError(''); }}
            className={`flex-1 py-3 px-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'inventory' 
                ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/50' 
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Database className="w-4 h-4" />
            Data Stok (DB1)
          </button>
          <button
            onClick={() => { setActiveTab('master'); setError(''); }}
            className={`flex-1 py-3 px-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'master' 
                ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/50' 
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Layers className="w-4 h-4" />
            Master Data (DB2)
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg flex items-start gap-2 text-sm">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <p>{error}</p>
            </div>
          )}

          <div 
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
              isDragging ? 'border-indigo-500 bg-indigo-50' : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50'
            }`}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-4">
                <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mb-3" />
                <p className="text-sm font-medium text-slate-700">Memproses Data...</p>
                {progress > 0 ? (
                  <div className="w-full max-w-xs mt-4">
                    <div className="flex justify-between text-xs text-slate-500 mb-1">
                      <span>Uploading...</span>
                      <span>{progress}%</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2.5">
                      <div className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 mt-1">Membaca dan menganalisis struktur file Excel Anda</p>
                )}
              </div>
            ) : (
              <>
                <FileSpreadsheet className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-sm font-bold text-slate-900 mb-1">
                  Tarik & Lepas File {activeTab === 'inventory' ? 'Stok (DB1)' : 'Master (DB2)'} di sini
                </h3>
                <p className="text-xs text-slate-500 mb-4">Mendukung format .xlsx, .xls, atau .csv</p>
                
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  accept=".xlsx, .xls, .csv" 
                  className="hidden" 
                />
                
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Pilih File
                </button>
              </>
            )}
          </div>

          <div className="mt-6 bg-slate-50 rounded-lg p-4 border border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Info {activeTab === 'inventory' ? 'DB1 (Stok & Demand)' : 'DB2 (Master Data)'}</h4>
            <p className="text-xs text-slate-600 mb-3 leading-relaxed">
              {activeTab === 'inventory' 
                ? 'Upload file ini secara rutin (harian/mingguan). Sistem akan mencari kolom Part No, Stok, dan Demand.'
                : 'Upload file ini jika ada update dari pusat (jarang). Sistem akan mencari kolom Part No, Kategori, dan Kelas ABC.'
              }
            </p>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-4">
              {activeTab === 'inventory' ? (
                <>
                  <li><span className="font-medium text-slate-800">Part No</span> (Part Number, Kode Item)</li>
                  <li><span className="font-medium text-slate-800">Stock</span> (Stok, Qty, Sisa)</li>
                  <li><span className="font-medium text-slate-800">Demand</span> (Demand Bulan 1, Jan, Feb, dll)</li>
                </>
              ) : (
                <>
                  <li><span className="font-medium text-slate-800">Part No</span> (Part Number, Kode Item)</li>
                  <li><span className="font-medium text-slate-800">Kategori</span> (Category, Group)</li>
                  <li><span className="font-medium text-slate-800">Kelas ABC</span> (ABC, Rank, Class)</li>
                </>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
