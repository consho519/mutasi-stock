export type Role = 'admin' | 'user';

export interface Branch {
  id: string;
  name: string;
  spreadsheetId: string;
}

export interface User {
  id: string;
  username: string;
  password?: string;
  role: Role;
  branchIds: string[];
}

export interface CurrentUser {
  id: string;
  username: string;
  role: Role;
  branchIds: string[];
}
